//
//  TestFairyApp.swift
//  TestFairy
//
//  Created by Charles Edge on 05/06/23.
//

import SwiftUI

@main
struct TestFairyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
